# The following are the documentation headers for each of the data sets in this R package.

#' Colon Cancer Data Set from Alon et al. (1999)
#'
#' The data set is a list made up of two elements:
#'	x: the 62 x 2000 matrix with the 2000 gene expressions from each of 62 patients
#'	y: the class membership of each patient.
#'
#'
#' To load data: data(alon)
#' Later, I will add more documentation here.
#'
#' @name alon
#' @docType data
#' @author John Ramey \email{johnramey@@gmail.com}
#' @references Alon et al. (1999)
#' @keywords data
NULL

#' Acute Lymphoblastic Leukemia (ALL) Data Set from Chiaretti et al. (1999)
#'
#' The data set is a list made up of two elements:
#'	x: the 111 x 12625 matrix with the 12625 gene expressions from each of 111 patients
#'	y: the class membership of each patient.
#'
#' To load data: data(chiaretti)
#' Later, I will add more documentation here.
#'
#' @name chiaretti
#' @docType data
#' @author John Ramey \email{johnramey@@gmail.com}
#' @references Chiaretti et al. (1999)
#' @keywords data
NULL

#' Methylation Data Set from Christensen et al. (2009)
#'
#' The data set is a list made up of two elements:
#'	x: the 217 x 1413 matrix with the 1413 gene expressions from each of 217 patients
#'	y: the class membership of each patient.
#'
#' To load data: data(christensen)
#' Later, I will add more documentation here.
#'
#' @name christensen
#' @docType data
#' @author John Ramey \email{johnramey@@gmail.com}
#' @references Christensen BC, Houseman EA, Marsit CJ, Zheng S, Wrensch MR, Wiemels JL, Nelson HH, Karagas MR, Padbury JF, Bueno R, Sugarbaker DJ, Yeh RF, Wiencke JK, Kelsey KT. (2009) Aging and environmental exposures alter tissue-specific DNA methylation dependent upon CpG island context. PLoS Genetics, 5, 8, 1 - 13.
#' @keywords data
NULL

#' Breast Cancer Data Set from Gravier et al. (2010)
#'
#' The data set is a list made up of two elements:
#'	x: the 168 x 2905 matrix with the 2905 gene expressions from each of 168 patients
#'	y: the class membership of each patient.
#'
#' To load data: data(gravier)
#'
#' From the paper's abstract:
#' The authors used Comparative Genomic Hybridization (CGH) array to analyze 168 pT1T2pN0 invasive ductal carcinoma patients
#' with either good (no event 5 years after diagnosis: 111 patients) or poor (57 patients with early onset metastasis) outcome.
#' NOTE: There are only 106 patients marked with "No Event" and there are 62 that had an event. We are off by 5.
#'
#' Transformation Applied: Normalized log2 ratio
#'
#' @name gravier
#' @docType data
#' @author John Ramey \email{johnramey@@gmail.com}
#' @references Gravier E, Pierron G, Vincent-Salomon A, Gruel N et al. (2010). A prognostic DNA signature for T1T2 node-negative breast cancer patients. Genes Chromosomes Cancer, 49, 12, 1125-34.
#' @keywords data
NULL

#' Khan Data Set
#'
#' The data set is a list made up of two elements:
#'	x: the 168 x 2905 matrix with the 2905 gene expressions from each of 168 patients
#'	y: the class membership of each patient.
#'
#' To load data: data(khan)
#' Later, I will add more documentation here.
#'
#' @name khan
#' @docType data
#' @author John Ramey \email{johnramey@@gmail.com}
#' @references TODO
#' @keywords data
NULL

#' Diffuse Large B-cell Lymphoma (DLBCL) Data Set from Shipp et al. (2002)
#'
#' The data set is a list made up of two elements:
#'	x: the 77 x 7129 matrix with the 7129 gene expressions from each of 77 patients
#'	y: the class membership of each patient.
#'
#' To load data: data(shipp)
#'
#' I found the data at:
#' http://datam.i2r.a-star.edu.sg/datasets/krbd/DLBCL/DLBCL-Harvard.html
#' Here is the information from the website:
#' There are two kinds of classifications about diffuse large b-cell lymphoma (DLBCL) addressed in the publication.
#' First one is DLBCL versus Follicular Lymphoma (FL) morphology. This set of data contains 58 DLBCL samples and 19 FL samples.
#' The second problem is to predict the patient outcome of DLBCL. Among 58 DLBCL patient samples, 32 of them are from cured
#' patients (labelled as 'cured') while 26 of them are from patients with fatal or refractory disease (labelled as 'fatal').
#' The expression profile contains 6817 genes.
#'
#' @name shipp
#' @docType data
#' @author John Ramey \email{johnramey@@gmail.com}
#' @references Margaret A. Shipp, et al. "Diffuse Large B-cell Lymphoma Outcome Prediction by Gene-expression Profiling and Supervised Machine Learning". Nature Medicine, 8(1):68-74, January 2002
#' @keywords data
NULL

#' Prostate Cancer Data Set from Singh et al. (2002)
#'
#' The data set is a list made up of two elements:
#'	x: the 102 x 12600 matrix with the 12600 gene expressions from each of 102 patients
#'	y: the class membership of each patient.
#'
#' To load data: data(singh)
#'
#' I found the data at:
#' http://datam.i2r.a-star.edu.sg/datasets/krbd/ProstateCancer/ProstateCancer.html
#' Raw Data:
#' (1) http://www-genome.wi.mit.edu/mpr/prostate
#' (2) http://carrier.gnf.org/welsh/prostate/
#' Here is the information from the website:
#' (A) Tumor versus Normal classification: training set (from (1)) contains 52 prostate tumor samples and
#' 50 non-tumor (labelled as "Normal") prostate samples with around 12600 genes. An independent set
#' of testing samplesfrom (2) is also prepared, which is from a different experiment and has a nearly 10-fold difference
#' in overall microarray intensity from the training data. Besides, we have removed extra genes contained in the testing samples.
#' In the above publication, the testing set is indicated to have 27 tumor and 8 normal samples.
#' However, from our extraction, there are 25 tumor and 9 normal samples.
#' (B) Prediction of clinical outcome: in this data set, 21 patients were evaluable with respect to recurrence following surgery
#' with 8 patients having relapsed and 13 patients having remained relapse free ("non-relapse") for at least 4 years.
#'
#' @name singh
#' @docType data
#' @author John Ramey \email{johnramey@@gmail.com}
#' @references Dinesh Singh, et al. "Gene Expression Correlates of Clinical Prostate Cancer Behavior". Cancer Cell, 1:203-209, March, 2002.
#' @keywords data
NULL